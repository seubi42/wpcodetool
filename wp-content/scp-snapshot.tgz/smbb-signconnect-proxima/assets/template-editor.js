/* SignConnect : éditeur visuel des zones d'un modèle (admin). */
(function () {
    'use strict';

    var V = window.ScpViewer;
    var Z = window.ScpZones;

    function round(value) {
        return Math.round(value * 10000) / 10000;
    }

    function parseList(text) {
        try {
            var list = JSON.parse(text || '[]');
            return Array.isArray(list) ? list : [];
        } catch (e) {
            return null;
        }
    }

    function el(tag, className, text) {
        var node = document.createElement(tag);

        if (className) {
            node.className = className;
        }

        if (text !== undefined) {
            node.textContent = text;
        }

        return node;
    }

    function init(root) {
        var config = {};

        try {
            config = JSON.parse(root.getAttribute('data-config') || '{}');
        } catch (e) {
            return;
        }

        var t = config.i18n || {};
        var form = root.closest('form') || document;
        var fieldsInput = form.querySelector('[name="field_zones"]');
        var detectInput = form.querySelector('[name="detection_zones"]');
        var mediaInput = form.querySelector('[name="sample_pdf_attachment_id"]');
        var viewer = root.querySelector('[data-scp-tpl-viewer]');
        var message = root.querySelector('[data-scp-tpl-message]');
        var panel = root.querySelector('[data-scp-tpl-rule]');
        var lastBox = root.querySelector('[data-scp-tpl-last]');
        var state = { type: 'signature', editor: null, numPages: 0, outside: [] };

        if (!fieldsInput || !detectInput || !V || !Z) {
            return;
        }

        function say(text, tone) {
            message.hidden = !text;
            message.textContent = text || '';
            message.className = 'scp-tpl-message' + (tone ? ' is-' + tone : '');
        }

        /* Barre de types */

        var types = root.querySelector('[data-scp-tpl-types]');
        var labels = Object.assign({}, config.fieldTypes || {}, { detect: t.detect || 'Reconnaissance', capture: t.capture || 'Destinataire' });
        var targets = { name: t.targetName || 'Nom complet', email: t.targetEmail || 'Email', phone: t.targetPhone || 'Mobile' };

        Object.keys(labels).forEach(function (type) {
            var button = el('button', 'scp-tpl-segment scp-zone--' + type + (type === state.type ? ' is-active' : ''), labels[type]);
            button.type = 'button';
            button.addEventListener('click', function () {
                state.type = type;
                types.querySelectorAll('.scp-tpl-segment').forEach(function (item) {
                    item.classList.toggle('is-active', item === button);
                });
            });
            types.appendChild(button);
        });

        /* Lecture / écriture du JSON */

        function load() {
            var fields = parseList(fieldsInput.value);
            var detects = parseList(detectInput.value);
            var list = [];
            var hasLast = false;
            state.outside = [];

            if (fields === null || detects === null) {
                say('JSON invalide dans les champs ci-dessous : corrigez-le ou videz-le pour utiliser l\'éditeur.', 'error');
                return false;
            }

            function add(zone, page, type, extra) {
                if (!Z.RULES[type]) {
                    return;
                }

                if (page < 1 || page > state.numPages) {
                    state.outside.push({ type: type, zone: zone });
                    return;
                }

                list.push(Object.assign({
                    page: page,
                    x: +zone.x || 0,
                    y: +zone.y || 0,
                    width: +zone.width || 0.01,
                    height: +zone.height || 0.01,
                    type: type
                }, extra || {}));
            }

            fields.forEach(function (zone) {
                var page = parseInt(zone.page, 10) || 1;
                hasLast = hasLast || page < 0;
                add(zone, page < 0 ? state.numPages + 1 + page : page, zone.type || zone.field_type || 'signature');
            });

            detects.forEach(function (zone) {
                if (zone.rule === 'capture') {
                    add(zone, parseInt(zone.page, 10) || 1, 'capture', { capture: targets[zone.capture] ? zone.capture : 'name' });
                    return;
                }

                add(zone, parseInt(zone.page, 10) || 1, 'detect', {
                    rule: zone.rule === 'number' ? 'number' : 'text',
                    text: String(zone.text || ''),
                    operator: Z.OPERATORS.indexOf(zone.operator) > -1 ? zone.operator : '>',
                    value: zone.value === undefined || zone.value === null ? '' : String(zone.value)
                });
            });

            if (fields.length) {
                lastBox.checked = hasLast;
            }

            say(state.outside.length ? (t.missing || '%d').replace('%d', state.outside.length) : '', 'warning');
            state.editor.set(list);
            showPanel(null);

            return true;
        }

        function save() {
            var fields = [];
            var detects = [];

            state.editor.zones().forEach(function (zone) {
                var box = { x: round(zone.x), y: round(zone.y), width: round(zone.width), height: round(zone.height) };

                if (zone.type === 'capture') {
                    detects.push(Object.assign({ page: zone.page }, box, { rule: 'capture', capture: zone.capture || 'name' }));
                } else if (zone.type === 'detect') {
                    var item = Object.assign({ page: zone.page }, box, { rule: zone.rule || 'text' });

                    if (item.rule === 'number') {
                        item.operator = zone.operator || '>';
                        item.value = zone.value || '';
                    } else {
                        item.text = zone.text || '';
                    }

                    detects.push(item);
                } else {
                    var page = lastBox.checked && zone.page === state.numPages ? -1 : zone.page;
                    fields.push(Object.assign({ page: page }, box, { type: zone.type }));
                }
            });

            state.outside.forEach(function (item) {
                (item.type === 'detect' || item.type === 'capture' ? detects : fields).push(item.zone);
            });

            fieldsInput.value = JSON.stringify(fields);
            detectInput.value = JSON.stringify(detects);
        }

        /* Zones de reconnaissance : texte lu, règle, libellé */

        function label(zone) {
            if (zone.type === 'capture') {
                return (t.capture || '') + ' → ' + targets[zone.capture || 'name'];
            }

            if (zone.type !== 'detect') {
                return labels[zone.type];
            }

            if (zone.rule === 'number') {
                return (t.ruleNumber || '') + ' ' + (zone.operator || '>') + ' ' + (zone.value || '?');
            }

            return zone.text ? '« ' + zone.text + ' »' : (t.detect || '') + ' · ' + (t.noText || '');
        }

        function read(zone) {
            var page = state.editor.page(zone);

            return page ? Z.textIn(page, zone).then(function (text) {
                zone.read = text;
                return text;
            }) : Promise.resolve('');
        }

        function showPanel(zone) {
            panel.innerHTML = '';
            panel.hidden = !zone || (zone.type !== 'detect' && zone.type !== 'capture');

            if (panel.hidden) {
                return;
            }

            if (zone.type === 'capture') {
                capturePanel(zone);
                return;
            }

            var head = el('div', 'scp-tpl-rule-head');
            head.appendChild(el('strong', '', t.ruleTitle || ''));
            var kinds = el('div', 'scp-tpl-segments');
            [['text', t.ruleText], ['number', t.ruleNumber]].forEach(function (kind) {
                var button = el('button', 'scp-tpl-segment' + ((zone.rule || 'text') === kind[0] ? ' is-active' : ''), kind[1]);
                button.type = 'button';
                button.addEventListener('click', function () {
                    zone.rule = kind[0];
                    changed(zone);
                    showPanel(zone);
                });
                kinds.appendChild(button);
            });
            head.appendChild(kinds);
            panel.appendChild(head);

            var row = el('div', 'scp-tpl-rule-row');

            if (zone.rule === 'number') {
                var operator = el('select');
                Z.OPERATORS.forEach(function (op) {
                    var option = el('option', '', op === '>=' ? '≥' : (op === '<=' ? '≤' : op));
                    option.value = op;
                    option.selected = op === (zone.operator || '>');
                    operator.appendChild(option);
                });
                operator.addEventListener('change', function () {
                    zone.operator = operator.value;
                    changed(zone);
                    status();
                });
                var value = el('input');
                value.type = 'text';
                value.placeholder = '10 000';
                value.value = zone.value || '';
                value.setAttribute('aria-label', t.valueLabel || '');
                value.addEventListener('input', function () {
                    zone.value = value.value.trim();
                    changed(zone);
                    status();
                });
                row.appendChild(el('span', '', t.ruleNumber || ''));
                row.appendChild(operator);
                row.appendChild(value);
            } else {
                var text = el('input', 'regular-text');
                text.type = 'text';
                text.value = zone.text || '';
                text.setAttribute('aria-label', t.textLabel || '');
                text.addEventListener('input', function () {
                    zone.text = text.value.replace(/\s+/g, ' ').trim();
                    changed(zone);
                    status();
                });
                var again = el('button', 'button', t.reread || '');
                again.type = 'button';
                again.addEventListener('click', function () {
                    read(zone).then(function (found) {
                        zone.text = found;
                        text.value = found;
                        changed(zone);
                        status();
                    });
                });
                row.appendChild(el('span', '', t.textLabel || ''));
                row.appendChild(text);
                row.appendChild(again);
            }

            panel.appendChild(row);
            var info = el('p', 'scp-tpl-rule-info');
            panel.appendChild(info);

            function status() {
                read(zone).then(function (found) {
                    var amount = Z.parseAmount(found);
                    var ok = Z.check(zone, found);
                    info.innerHTML = '';
                    info.appendChild(document.createTextNode((t.read || '') + ' '));
                    info.appendChild(el('code', '', found || '—'));

                    if (zone.rule === 'number') {
                        info.appendChild(document.createTextNode(' · ' + (t.amount || '') + ' : ' + (amount === null ? '—' : amount.toLocaleString('fr-FR'))));
                    }

                    info.appendChild(el('span', 'scp-tpl-rule-status ' + (ok ? 'is-ok' : 'is-ko'), ok ? (t.ok || '') : (t.ko || '')));
                });
            }

            status();
        }

        /* Zone « destinataire » : ce qu'elle capte pour préremplir l'envoi. */
        function capturePanel(zone) {
            var head = el('div', 'scp-tpl-rule-head');
            head.appendChild(el('strong', '', t.captureTitle || ''));
            var kinds = el('div', 'scp-tpl-segments');
            Object.keys(targets).forEach(function (key) {
                var button = el('button', 'scp-tpl-segment' + ((zone.capture || 'name') === key ? ' is-active' : ''), targets[key]);
                button.type = 'button';
                button.addEventListener('click', function () {
                    zone.capture = key;
                    changed(zone);
                    capturePanel(zone);
                });
                kinds.appendChild(button);
            });
            head.appendChild(kinds);
            panel.innerHTML = '';
            panel.appendChild(head);
            var info = el('p', 'scp-tpl-rule-info');
            panel.appendChild(info);

            read(zone).then(function (found) {
                var value = Z.extract(zone.capture || 'name', found);
                info.innerHTML = '';
                info.appendChild(document.createTextNode((t.read || '') + ' '));
                info.appendChild(el('code', '', found || '—'));
                info.appendChild(document.createTextNode(' → '));
                info.appendChild(el('strong', '', value || '—'));
                info.appendChild(el('span', 'scp-tpl-rule-status ' + (value ? 'is-ok' : 'is-ko'), value ? (t.captureOk || '') : (t.captureKo || '')));
            });
        }

        function changed(zone) {
            state.editor.relabel(zone);
            save();
        }

        /* Chargement du PDF d'exemple */

        function show(url) {
            panel.hidden = true;

            if (!url) {
                state.editor = null;
                viewer.innerHTML = '<div class="scp-tpl-empty">' + (t.noPdf || '') + '</div>';
                return;
            }

            V.render(viewer, url, t.page).then(function (pages) {
                state.numPages = pages.numPages || pages.length;
                state.editor = Z.editor({
                    pages: pages,
                    type: function () {
                        return state.type;
                    },
                    label: label,
                    removeLabel: t.remove,
                    onChange: function () {
                        if (state.editor) {
                            save();
                        }
                    },
                    onSelect: showPanel,
                    onCreate: function (zone) {
                        if (zone.type === 'capture') {
                            zone.capture = 'name';
                            changed(zone);
                            showPanel(zone);
                        } else if (zone.type === 'detect') {
                            zone.rule = 'text';
                            zone.operator = '>';
                            zone.value = '';
                            read(zone).then(function (found) {
                                zone.text = found;
                                changed(zone);
                                showPanel(zone);
                            });
                        }
                    },
                    onMove: function (zone) {
                        if ((zone.type === 'detect' || zone.type === 'capture') && state.editor.selected() === zone) {
                            showPanel(zone);
                        }
                    }
                });
                load();
            }).catch(function () {
                viewer.innerHTML = '';
                say(t.error, 'error');
            });
        }

        // Le champ média de CodeTool change sa valeur sans événement : on surveille.
        var currentMedia = mediaInput ? mediaInput.value : '';

        if (mediaInput) {
            window.setInterval(function () {
                if (mediaInput.value === currentMedia) {
                    return;
                }

                currentMedia = mediaInput.value;

                if (!currentMedia) {
                    show('');
                    return;
                }

                var body = new FormData();
                body.append('action', config.action);
                body.append('_wpnonce', config.nonce);
                body.append('attachment_id', currentMedia);
                V.post(config.ajaxUrl, body).then(function (data) {
                    say('');
                    show(data.url);
                }).catch(function (error) {
                    show('');
                    say(error.message || t.error, 'error');
                });
            }, 600);
        }

        // Une saisie manuelle dans le JSON redessine les zones.
        [fieldsInput, detectInput].forEach(function (input) {
            input.addEventListener('change', function () {
                if (state.editor) {
                    load();
                }
            });
        });

        lastBox.addEventListener('change', function () {
            if (state.editor) {
                save();
            }
        });

        show(config.pdfUrl);
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-scp-template-editor]').forEach(init);
    });
})();
