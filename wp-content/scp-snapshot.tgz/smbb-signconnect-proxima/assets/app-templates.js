/* SignConnect : onglet « Modèles » de l'app (import du PDF d'exemple, suppression). */
(function () {
    'use strict';

    var V = window.ScpViewer;

    document.querySelectorAll('[data-scp-tpl-form]').forEach(function (form) {
        var file = form.querySelector('[data-scp-tpl-file]');
        var label = form.querySelector('[data-scp-tpl-file-label]');
        var name = form.querySelector('[data-scp-tpl-file-name]');
        var hidden = form.querySelector('[name="sample_pdf_attachment_id"]');
        var del = form.querySelector('[data-scp-tpl-delete]');
        var idle = label.textContent;

        file.addEventListener('change', function () {
            if (!file.files || !file.files[0]) {
                return;
            }

            var body = new FormData();
            body.append('action', 'scp_app_templatesample');
            body.append('_wpnonce', form.getAttribute('data-nonce'));
            body.append('organization_id', form.querySelector('[name="organization_id"]').value);
            body.append('file', file.files[0]);
            label.textContent = '…';
            label.parentNode.classList.add('is-busy');

            V.post(form.getAttribute('data-ajax'), body).then(function (data) {
                /* L'éditeur surveille ce champ et affiche le nouveau PDF. */
                hidden.value = String(data.id);
                name.textContent = data.name;
                idle = label.getAttribute('data-change') || idle;
            }).catch(function (error) {
                name.textContent = error.message || '';
            }).then(function () {
                label.textContent = idle;
                label.parentNode.classList.remove('is-busy');
                file.value = '';
            });
        });

        if (del) {
            del.addEventListener('click', function (event) {
                if (!window.confirm(form.getAttribute('data-confirm'))) {
                    event.preventDefault();
                }
            });
        }
    });
})();
