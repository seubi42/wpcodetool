<?php

namespace Smbb\SignConnectProxima\Front;

use Smbb\SignConnectProxima\Repository\Documents;
use Smbb\SignConnectProxima\Repository\Memberships;
use Smbb\SignConnectProxima\Repository\Organizations;
use Smbb\SignConnectProxima\Service\Billing;
use Smbb\SignConnectProxima\Service\SendService;
use Smbb\SignConnectProxima\Service\SigningService;
use Smbb\SignConnectProxima\Service\TemplateService;
use Smbb\SignConnectProxima\Service\Storage;
use Smbb\SignConnectProxima\Service\UniversignFlow;
use Smbb\SignConnectProxima\Service\Usage;
use Smbb\SignConnectProxima\Support\Inbox;
use Smbb\SignConnectProxima\Support\Levels;
use Smbb\SignConnectProxima\Support\UserPrefs;

defined('ABSPATH') || exit;

/**
 * Points d'entrée AJAX de l'app (connecté) et de la page de signature (public).
 */
final class Ajax
{
    const APP_NONCE = 'scp_app';

    public static function hooks()
    {
        foreach (array('upload', 'draft', 'send', 'remind', 'cancel', 'pdf', 'templatesample', 'templatepdf', 'inbox') as $action) {
            add_action('wp_ajax_scp_app_' . $action, array(__CLASS__, 'app' . ucfirst($action)));
        }

        foreach (array('pdf', 'sign', 'refuse') as $action) {
            add_action('wp_ajax_scp_public_' . $action, array(__CLASS__, 'public' . ucfirst($action)));
            add_action('wp_ajax_nopriv_scp_public_' . $action, array(__CLASS__, 'public' . ucfirst($action)));
        }
    }

    public static function appUpload()
    {
        $user_id = self::appUser();

        self::respond(function () use ($user_id) {
            $file = isset($_FILES['file']) && is_array($_FILES['file']) ? $_FILES['file'] : array();
            $document = SendService::upload($user_id, isset($_POST['team_id']) ? absint($_POST['team_id']) : 0, $file);

            return self::flowPayload($user_id, $document);
        });
    }

    /** Reprise d'un brouillon (client Windows, ou lien ?scp_draft=ID) : mêmes données qu'après un dépôt. */
    public static function appDraft()
    {
        $user_id = self::appUser();

        self::respond(function () use ($user_id) {
            $document = Documents::find(isset($_POST['document_id']) ? absint($_POST['document_id']) : 0);

            if (!$document || (int) $document['sender_id'] !== (int) $user_id || !empty($document['deleted_flag'])) {
                throw new \RuntimeException(__('Document introuvable.', 'smbb-signconnect-proxima'));
            }

            if ($document['status'] !== 'draft') {
                throw new \RuntimeException(__('Ce document a déjà été envoyé.', 'smbb-signconnect-proxima'));
            }

            return self::flowPayload($user_id, $document);
        });
    }

    private static function flowPayload($user_id, array $document)
    {
        $organization = Organizations::find($document['organization_id']);

        return array(
            'document' => self::documentPayload($document),
            'pdfUrl' => self::appPdfUrl($document['id']),
            'templates' => SendService::templates($document['organization_id']),
            'channels' => $organization['internal_channels'],
            'hasTwilio' => Organizations::hasTwilio($organization),
            'hasStamp' => !empty($organization['stamp_attachment_id']),
            'defaultMessage' => (string) $organization['default_send_message'],
            'validityDays' => (int) $organization['send_validity_days'],
            'levels' => self::levels($organization, $document),
            'hasSenderSignature' => UserPrefs::hasSignature($user_id),
            'defaultLevel' => self::defaultLevel($organization),
            'authMeans' => (string) $organization['simple_auth_means'] === 'email' ? 'email' : 'sms',
        );
    }

    /** PDF d'exemple d'un modèle, importé depuis l'onglet « Modèles ». */
    public static function appTemplatesample()
    {
        $user_id = self::appUser();

        self::respond(function () use ($user_id) {
            $file = isset($_FILES['file']) && is_array($_FILES['file']) ? $_FILES['file'] : array();

            return TemplateService::uploadSample($user_id, isset($_POST['organization_id']) ? absint($_POST['organization_id']) : 0, $file);
        });
    }

    /** URL d'un PDF d'exemple, demandée par l'éditeur de zones quand il change. */
    public static function appTemplatepdf()
    {
        $user_id = self::appUser();

        self::respond(function () use ($user_id) {
            $url = TemplateService::sampleUrl($user_id, isset($_POST['attachment_id']) ? absint($_POST['attachment_id']) : 0);

            if ($url === '') {
                throw new \RuntimeException(__("Ce PDF d'exemple n'est pas accessible.", 'smbb-signconnect-proxima'));
            }

            return array('url' => $url);
        });
    }

    /** Notifications : marquer comme lues. */
    public static function appInbox()
    {
        $user_id = self::appUser();

        self::respond(function () use ($user_id) {
            Inbox::markRead($user_id);

            return array('unread' => 0);
        });
    }

    public static function appSend()
    {
        $user_id = self::appUser();

        self::respond(function () use ($user_id) {
            $input = wp_unslash($_POST);
            $document = SendService::send($user_id, isset($input['document_id']) ? absint($input['document_id']) : 0, $input);

            return array('document' => self::documentPayload($document));
        });
    }

    public static function appRemind()
    {
        $user_id = self::appUser();

        self::respond(function () use ($user_id) {
            return array('document' => self::documentPayload(SendService::remind($user_id, isset($_POST['document_id']) ? absint($_POST['document_id']) : 0)));
        });
    }

    public static function appCancel()
    {
        $user_id = self::appUser();

        self::respond(function () use ($user_id) {
            return array('document' => self::documentPayload(SendService::cancel($user_id, isset($_POST['document_id']) ? absint($_POST['document_id']) : 0)));
        });
    }

    /**
     * PDF pour l'expéditeur : source (aperçu) ou signé (téléchargement).
     */
    public static function appPdf()
    {
        $user_id = self::appUser();

        try {
            $document = SendService::viewable($user_id, isset($_GET['document_id']) ? absint($_GET['document_id']) : 0);
            $what = isset($_GET['signed']) ? ($_GET['signed'] === 'evidence' ? 'evidence' : 'signed') : 'source';
            self::streamPdf($document, $what, !empty($_GET['download']));
        } catch (\Throwable $exception) {
            wp_die(esc_html($exception->getMessage()), '', array('response' => 404));
        }
    }

    public static function publicPdf()
    {
        $resolved = self::publicDocument($_GET);

        if (!in_array($resolved['state'], array('pending', 'signed'), true)) {
            wp_die(esc_html__('Document indisponible.', 'smbb-signconnect-proxima'), '', array('response' => 404));
        }

        try {
            self::streamPdf($resolved['document'], $resolved['state'] === 'signed' ? 'signed' : 'source', !empty($_GET['download']));
        } catch (\Throwable $exception) {
            wp_die(esc_html__('Document indisponible.', 'smbb-signconnect-proxima'), '', array('response' => 404));
        }
    }

    public static function publicSign()
    {
        $resolved = self::publicDocument($_POST);

        self::respond(function () use ($resolved) {
            self::assertPending($resolved);
            $input = wp_unslash($_POST);
            SigningService::sign($resolved['document'], $resolved['organization'], array(
                'signature' => isset($input['signature']) ? $input['signature'] : '',
                'signer_name' => isset($input['signer_name']) ? $input['signer_name'] : '',
                'consent' => !empty($input['consent']),
            ));

            return array('downloadUrl' => self::publicPdfUrl($_POST, true));
        });
    }

    public static function publicRefuse()
    {
        $resolved = self::publicDocument($_POST);

        self::respond(function () use ($resolved) {
            self::assertPending($resolved);
            $input = wp_unslash($_POST);
            SigningService::refuse($resolved['document'], $resolved['organization'], array(
                'message' => isset($input['message']) ? $input['message'] : '',
                'signer_name' => isset($input['signer_name']) ? $input['signer_name'] : '',
            ));

            return array();
        });
    }

    /**
     * @param bool|string $signed false = original, true = signé, 'evidence' = attestation de preuve Universign
     */
    public static function appPdfUrl($document_id, $signed = false, $download = false)
    {
        return add_query_arg(array_filter(array(
            'action' => 'scp_app_pdf',
            'document_id' => absint($document_id),
            'signed' => $signed === 'evidence' ? 'evidence' : ($signed ? 1 : null),
            'download' => $download ? 1 : null,
            '_wpnonce' => wp_create_nonce(self::APP_NONCE),
        )), admin_url('admin-ajax.php'));
    }

    /**
     * @param array<string,mixed> $source contient scp_doc et scp_t
     */
    public static function publicPdfUrl(array $source, $download = false)
    {
        return add_query_arg(array_filter(array(
            'action' => 'scp_public_pdf',
            'scp_doc' => isset($source['scp_doc']) ? sanitize_text_field(wp_unslash($source['scp_doc'])) : '',
            'scp_t' => isset($source['scp_t']) ? sanitize_text_field(wp_unslash($source['scp_t'])) : '',
            'download' => $download ? 1 : null,
        )), admin_url('admin-ajax.php'));
    }

    /**
     * Niveaux affichés à l'envoi : tous ceux cochés sur l'organisation, avec leur phrase d'usage.
     */
    private static function levels(array $organization, array $document = array())
    {
        $available = Organizations::availableLevels($organization);
        $levels = array();
        $membership = !empty($document['membership_id']) ? Memberships::find((int) $document['membership_id']) : null;
        $gauges = $membership ? Usage::gauges($membership, Billing::currentMonth()) : array();

        foreach (Levels::all() as $level) {
            if (!in_array($level, (array) $organization['allowed_levels'], true)) {
                continue;
            }

            $levels[] = array(
                'key' => $level,
                'label' => Levels::label($level),
                'usage' => isset($organization['level_usage_' . $level]) ? (string) $organization['level_usage_' . $level] : '',
                'description' => Levels::description($level),
                'norms' => Levels::norm($level),
                'available' => in_array($level, $available, true),
                'rank' => Levels::rank($level),
                'credits' => isset($gauges[$level]) ? Usage::credits($gauges[$level]) : null,
            );
        }

        return $levels;
    }

    private static function defaultLevel(array $organization)
    {
        $available = Organizations::availableLevels($organization);
        $default = isset($organization['default_level']) ? (string) $organization['default_level'] : '';

        return in_array($default, $available, true) ? $default : (string) reset($available);
    }

    public static function documentPayload(array $document)
    {
        return array(
            'id' => (int) $document['id'],
            'filename' => (string) $document['filename'],
            'pageCount' => (int) $document['page_count'],
            'status' => (string) $document['status'],
            'organizationId' => (int) $document['organization_id'],
        );
    }

    private static function publicDocument(array $source)
    {
        return SigningService::resolve(
            isset($source['scp_doc']) ? sanitize_text_field(wp_unslash($source['scp_doc'])) : '',
            isset($source['scp_t']) ? sanitize_text_field(wp_unslash($source['scp_t'])) : ''
        );
    }

    private static function assertPending(array $resolved)
    {
        $messages = array(
            'invalid' => __('Lien de signature invalide.', 'smbb-signconnect-proxima'),
            'blocked' => __('Ce document est temporairement indisponible.', 'smbb-signconnect-proxima'),
            'expired' => __('Ce lien a expiré.', 'smbb-signconnect-proxima'),
        );

        if ($resolved['state'] !== 'pending') {
            throw new \RuntimeException(isset($messages[$resolved['state']]) ? $messages[$resolved['state']] : __('Ce document a déjà été traité.', 'smbb-signconnect-proxima'));
        }
    }

    private static function appUser()
    {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => __('Session expirée : reconnectez-vous.', 'smbb-signconnect-proxima')), 401);
        }

        if (!check_ajax_referer(self::APP_NONCE, '_wpnonce', false)) {
            wp_send_json_error(array('message' => __('Session expirée : rechargez la page.', 'smbb-signconnect-proxima')), 403);
        }

        return get_current_user_id();
    }

    private static function respond(callable $callback)
    {
        try {
            wp_send_json_success($callback());
        } catch (\InvalidArgumentException $exception) {
            wp_send_json_error(array('message' => $exception->getMessage()), 422);
        } catch (\Throwable $exception) {
            wp_send_json_error(array('message' => $exception->getMessage()), 400);
        }
    }

    /**
     * Le signé est disponible pour un document signé ; l'attestation pour un envoi Universign terminé.
     */
    public static function hasFile(array $document, $what)
    {
        $universign = !empty($document['universign_transaction_id']) && $document['signature_level'] !== Levels::INTERNAL;

        if ($what === 'signed') {
            return $document['status'] === 'signed' && (!empty($document['signed_storage_path']) || $universign);
        }

        if ($what === 'evidence') {
            return in_array($document['status'], array('signed', 'refused', 'expired', 'cancelled'), true) && (!empty($document['evidence_storage_path']) || $universign);
        }

        return !empty($document['source_storage_path']);
    }

    /**
     * @param string $what source|signed|evidence
     */
    public static function streamPdf(array $document, $what, $download)
    {
        $organization = Organizations::find($document['organization_id']);
        $columns = array('source' => 'source_storage_path', 'signed' => 'signed_storage_path', 'evidence' => 'evidence_storage_path');
        $what = isset($columns[$what]) ? $what : 'source';
        $key = $document[$columns[$what]];

        if (!$organization || !self::hasFile($document, $what)) {
            throw new \RuntimeException(__('Document indisponible.', 'smbb-signconnect-proxima'));
        }

        // Sans copie sur S3, le PDF signé et l'attestation sont lus chez Universign.
        $path = $key ? Storage::forOrganization($organization)->download($key) : UniversignFlow::download($document, $what);
        $suffixes = array('source' => '', 'signed' => '-signe', 'evidence' => '-preuve');
        $name = preg_replace('/\.pdf$/i', '', (string) $document['filename']) . $suffixes[$what] . '.pdf';

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        nocache_headers();
        header('Content-Type: application/pdf');
        header('Content-Disposition: ' . ($download ? 'attachment' : 'inline') . '; filename="' . str_replace('"', '', sanitize_file_name($name)) . '"');
        header('Content-Length: ' . filesize($path));
        header('X-Content-Type-Options: nosniff');
        header('X-Robots-Tag: noindex, nofollow');
        readfile($path);
        @unlink($path);
        exit;
    }
}
