<?php

namespace Smbb\SignConnectProxima\Front;

use Smbb\SignConnectProxima\Repository\Documents;
use Smbb\SignConnectProxima\Repository\Organizations;
use Smbb\SignConnectProxima\Service\SigningService;

defined('ABSPATH') || exit;

/**
 * [signconnect_signature] : page publique où le signataire lit, signe ou refuse.
 */
final class SignShortcode
{
    const TAG = 'signconnect_signature';

    public static function hooks()
    {
        // Le lien contient un jeton : pas d'indexation, pas de fuite par le referer.
        add_action('wp_head', array(__CLASS__, 'privacyHeaders'), 1);
    }

    public static function privacyHeaders()
    {
        if (isset($_GET['scp_doc'])) {
            echo '<meta name="robots" content="noindex, nofollow">' . "\n" . '<meta name="referrer" content="no-referrer">' . "\n";
        }
    }

    public static function render()
    {
        $source = array(
            'scp_doc' => isset($_GET['scp_doc']) ? sanitize_text_field(wp_unslash($_GET['scp_doc'])) : '',
            'scp_t' => isset($_GET['scp_t']) ? sanitize_text_field(wp_unslash($_GET['scp_t'])) : '',
        );

        if ($source['scp_doc'] === '') {
            return Assets::wrap(Assets::message(__('Signature électronique', 'smbb-signconnect-proxima'), __('Ouvrez le lien reçu par email ou SMS pour accéder à votre document.', 'smbb-signconnect-proxima')), 'scp-sign');
        }

        $resolved = SigningService::resolve($source['scp_doc'], $source['scp_t']);
        $document = $resolved['document'];
        $organization = $resolved['organization'];
        $color = $organization ? Organizations::brandColor($organization) : '';

        switch ($resolved['state']) {
            case 'invalid':
                return Assets::wrap(Assets::message(__('Lien invalide', 'smbb-signconnect-proxima'), __('Ce lien de signature est incomplet ou n\'existe plus. Vérifiez que vous avez copié le lien en entier.', 'smbb-signconnect-proxima'), 'error'), 'scp-sign');

            case 'blocked':
                return Assets::wrap(self::header($organization, $document) . Assets::message(__('Document momentanément indisponible', 'smbb-signconnect-proxima'), __("Contactez la personne qui vous l'a envoyé.", 'smbb-signconnect-proxima'), 'warning'), 'scp-sign', $color);

            case 'expired':
                return Assets::wrap(self::header($organization, $document) . Assets::message(__('Ce lien a expiré', 'smbb-signconnect-proxima'), __("Demandez un nouvel envoi à la personne qui vous l'a adressé.", 'smbb-signconnect-proxima'), 'warning'), 'scp-sign', $color);

            case 'signed':
                return Assets::wrap(self::header($organization, $document) . Assets::message(__('Document signé', 'smbb-signconnect-proxima'), sprintf(__('Signé le %s. Une copie vous a été envoyée par email.', 'smbb-signconnect-proxima'), mysql2date('d/m/Y à H:i', $document['signed_at'])), 'success')
                    . '<div class="scp-actions scp-actions--center"><a class="scp-button" href="' . esc_url(Ajax::publicPdfUrl($source, true)) . '">' . esc_html__('Télécharger le document signé', 'smbb-signconnect-proxima') . '</a></div>', 'scp-sign', $color);

            case 'refused':
                return Assets::wrap(self::header($organization, $document) . Assets::message(__('Signature refusée', 'smbb-signconnect-proxima'), __("Votre refus a été transmis à l'expéditeur.", 'smbb-signconnect-proxima')), 'scp-sign', $color);

            case 'closed':
                return Assets::wrap(self::header($organization, $document) . Assets::message(__('Ce document n\'attend plus de signature', 'smbb-signconnect-proxima'), ''), 'scp-sign', $color);
        }

        SigningService::markOpened($document);
        $fields = array_map(function ($field) {
            return array(
                'page_number' => (int) $field['page_number'],
                'x' => (float) $field['x'],
                'y' => (float) $field['y'],
                'width' => (float) $field['width'],
                'height' => (float) $field['height'],
                'field_type' => (string) $field['field_type'],
            );
        }, Documents::fields($document['id']));
        $signer_name = Documents::recipientName($document);

        Assets::enqueue('sign', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'doc' => $source['scp_doc'],
            'token' => $source['scp_t'],
            'pdfUrl' => Ajax::publicPdfUrl($source),
            'fields' => $fields,
            'i18n' => array(
                'signHere' => __('Signez ici', 'smbb-signconnect-proxima'),
                'name' => __('Votre nom', 'smbb-signconnect-proxima'),
                'date' => __('Date', 'smbb-signconnect-proxima'),
                'stamp' => __('Tampon', 'smbb-signconnect-proxima'),
                'signing' => __('Signature en cours…', 'smbb-signconnect-proxima'),
                'error' => __('Une erreur est survenue. Réessayez.', 'smbb-signconnect-proxima'),
                'page' => __('Page', 'smbb-signconnect-proxima'),
            ),
        ));

        $html = self::header($organization, $document);
        $html .= '<div class="scp-viewer scp-viewer--read" data-scp-viewer></div>';
        $html .= '<section class="scp-card scp-sign-panel" data-scp-sign-panel>';
        $html .= '<h2>' . esc_html__('Signer ce document', 'smbb-signconnect-proxima') . '</h2>';
        $html .= '<form data-scp-sign-form novalidate>';
        $html .= '<label class="scp-field"><span>' . esc_html__('Nom complet', 'smbb-signconnect-proxima') . '</span><input name="signer_name" value="' . esc_attr($signer_name) . '" autocomplete="name" required></label>';
        $html .= '<div class="scp-field"><span>' . esc_html__('Votre signature', 'smbb-signconnect-proxima') . '</span>'
            . '<div class="scp-pad"><canvas data-scp-pad aria-label="' . esc_attr__('Zone de signature', 'smbb-signconnect-proxima') . '"></canvas><button type="button" class="scp-link" data-scp-clear>' . esc_html__('Effacer', 'smbb-signconnect-proxima') . '</button></div>'
            . '<small class="scp-muted">' . esc_html__('Dessinez avec la souris ou le doigt.', 'smbb-signconnect-proxima') . '</small></div>';
        $html .= '<label class="scp-check"><input type="checkbox" name="consent" value="1"> <span>' . esc_html__("J'ai lu le document et j'accepte de le signer électroniquement.", 'smbb-signconnect-proxima') . '</span></label>';
        $html .= '<div class="scp-alert" data-scp-message hidden></div>';
        $html .= '<div class="scp-actions"><button type="button" class="scp-button scp-button--ghost" data-scp-refuse-toggle>' . esc_html__('Refuser', 'smbb-signconnect-proxima') . '</button>'
            . '<button type="submit" class="scp-button">' . esc_html__('Signer', 'smbb-signconnect-proxima') . '</button></div>';
        $html .= '</form>';
        $html .= '<form class="scp-refuse" data-scp-refuse-form hidden novalidate>';
        $html .= '<label class="scp-field"><span>' . esc_html__('Pourquoi refusez-vous de signer ?', 'smbb-signconnect-proxima') . '</span><textarea name="message" rows="3" required></textarea></label>';
        $html .= '<div class="scp-actions"><button type="button" class="scp-button scp-button--ghost" data-scp-refuse-toggle>' . esc_html__('Retour', 'smbb-signconnect-proxima') . '</button>'
            . '<button type="submit" class="scp-button scp-button--danger">' . esc_html__('Confirmer le refus', 'smbb-signconnect-proxima') . '</button></div>';
        $html .= '</form>';
        $html .= '</section>';
        $html .= '<section class="scp-card" data-scp-sign-done hidden>' . Assets::message(__('Merci, c\'est signé !', 'smbb-signconnect-proxima'), __('Une copie du document signé vous a été envoyée par email.', 'smbb-signconnect-proxima'), 'success')
            . '<div class="scp-actions scp-actions--center"><a class="scp-button" data-scp-download href="#">' . esc_html__('Télécharger le document signé', 'smbb-signconnect-proxima') . '</a></div></section>';
        $html .= '<section class="scp-card" data-scp-refuse-done hidden>' . Assets::message(__('Refus transmis', 'smbb-signconnect-proxima'), __("L'expéditeur a été prévenu.", 'smbb-signconnect-proxima')) . '</section>';

        return Assets::wrap($html, 'scp-sign', $color);
    }

    private static function header($organization, $document)
    {
        if (!$organization || !$document) {
            return '';
        }

        $logo = !empty($organization['logo_attachment_id']) ? wp_get_attachment_image_url((int) $organization['logo_attachment_id'], 'medium') : '';
        $sender = !empty($document['sender_id']) ? get_userdata((int) $document['sender_id']) : false;

        return '<header class="scp-sign-header">'
            . ($logo ? '<img class="scp-logo" src="' . esc_url($logo) . '" alt="' . esc_attr($organization['name']) . '">' : '<span class="scp-org">' . esc_html($organization['name']) . '</span>')
            . '<div><h1>' . esc_html($document['filename']) . '</h1>'
            . ($sender ? '<p class="scp-muted">' . esc_html(sprintf(__('Envoyé par %1$s · %2$s', 'smbb-signconnect-proxima'), $sender->display_name, $organization['name'])) . '</p>' : '')
            . '</div></header>';
    }
}
