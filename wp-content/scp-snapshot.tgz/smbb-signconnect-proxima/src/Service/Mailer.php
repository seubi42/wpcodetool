<?php

namespace Smbb\SignConnectProxima\Service;

use Smbb\SignConnectProxima\Repository\Documents;
use Smbb\SignConnectProxima\Repository\Organizations;
use Smbb\SignConnectProxima\Support\Token;
use Smbb\SignConnectProxima\Support\Inbox;
use Smbb\SignConnectProxima\Support\UserPrefs;

defined('ABSPATH') || exit;

/**
 * Emails et SMS de la signature interne. Les emails partent par wp_mail()
 * (un plugin SMTP peut prendre le relais), aux couleurs de l'organisation.
 */
final class Mailer
{
    /**
     * Demande de signature (ou relance) par les canaux choisis à l'envoi.
     *
     * @return string[] canaux effectivement utilisés
     */
    public static function signatureRequest(array $document, array $organization, $is_reminder = false)
    {
        $url = Token::signingUrl($document);
        $sender = self::senderName($document);
        $channels = $document['delivery_channels'] ?: array('email');
        $used = array();
        $expires = !empty($document['expires_at']) ? mysql2date('d/m/Y', $document['expires_at']) : '';

        if (in_array('email', $channels, true) && is_email($document['recipient_email'])) {
            $title = $is_reminder
                ? sprintf(__('Rappel : %s attend votre signature', 'smbb-signconnect-proxima'), $document['filename'])
                : sprintf(__('%1$s vous invite à signer %2$s', 'smbb-signconnect-proxima'), $sender, $document['filename']);
            $body = '<p>' . esc_html(sprintf(__('Bonjour %s,', 'smbb-signconnect-proxima'), Documents::recipientName($document))) . '</p>';
            $body .= '<p>' . esc_html(sprintf(
                $is_reminder ? __('%1$s (%2$s) attend toujours votre signature sur le document « %3$s ».', 'smbb-signconnect-proxima') : __('%1$s (%2$s) vous invite à signer le document « %3$s ».', 'smbb-signconnect-proxima'),
                $sender,
                $organization['name'],
                $document['filename']
            )) . '</p>';

            if (!empty($document['send_message'])) {
                $body .= '<blockquote style="margin:16px 0;padding:12px 16px;background:#f6f7f9;border-left:3px solid ' . esc_attr(Organizations::brandColor($organization)) . ';border-radius:4px;">' . nl2br(esc_html($document['send_message'])) . '</blockquote>';
            }

            if ($expires !== '') {
                $body .= '<p style="color:#6b7280;font-size:13px;">' . esc_html(sprintf(__('Ce lien est personnel et valable jusqu\'au %s.', 'smbb-signconnect-proxima'), $expires)) . '</p>';
            }

            self::email($organization, $document['recipient_email'], $title, $title, $body, array(__('Lire et signer', 'smbb-signconnect-proxima'), $url));
            $used[] = 'email';
        }

        if (in_array('sms', $channels, true) && !empty($document['recipient_phone']) && Organizations::hasTwilio($organization)) {
            Sms::send($organization, $document['recipient_phone'], sprintf(
                $is_reminder ? __('Rappel %1$s : document « %2$s » à signer : %3$s', 'smbb-signconnect-proxima') : __('%1$s vous invite à signer « %2$s » : %3$s', 'smbb-signconnect-proxima'),
                $is_reminder ? $organization['name'] : $sender,
                self::shorten($document['filename'], 40),
                $url
            ));
            $used[] = 'sms';
        }

        if (!$used) {
            throw new \RuntimeException(__("Aucun canal n'a pu être utilisé pour prévenir le signataire.", 'smbb-signconnect-proxima'));
        }

        return $used;
    }

    public static function signedToSigner(array $document, array $organization, $signed_pdf)
    {
        if (!is_email($document['recipient_email'])) {
            return;
        }

        $title = sprintf(__('Votre exemplaire signé : %s', 'smbb-signconnect-proxima'), $document['filename']);
        $body = '<p>' . esc_html__('Merci, votre signature a bien été enregistrée.', 'smbb-signconnect-proxima') . '</p>'
            . '<p>' . esc_html(sprintf(__('Vous trouverez en pièce jointe le document signé, avec son certificat de signature (%s).', 'smbb-signconnect-proxima'), $organization['name'])) . '</p>';

        self::email($organization, $document['recipient_email'], $title, __('Document signé', 'smbb-signconnect-proxima'), $body, null, array(self::attachment($signed_pdf, $document)));
    }

    public static function signedToSender(array $document, array $organization, $signed_pdf)
    {
        Inbox::document($document, 'signed');
        $email = self::senderEmail($document);

        if ($email === '' || !UserPrefs::wants((int) $document['sender_id'], 'signed')) {
            return;
        }

        $title = sprintf(__('Signé : %s', 'smbb-signconnect-proxima'), $document['filename']);
        $body = '<p>' . esc_html(sprintf(__('%1$s a signé « %2$s ».', 'smbb-signconnect-proxima'), $document['signer_name'] ?: $document['recipient_email'], $document['filename'])) . '</p>'
            . '<p>' . esc_html__('Le PDF signé et son certificat sont joints à cet email.', 'smbb-signconnect-proxima') . '</p>';

        self::email($organization, $email, $title, __('Document signé', 'smbb-signconnect-proxima'), $body, array(__('Voir mes envois', 'smbb-signconnect-proxima'), Token::appUrl(array('scp_view' => 'documents'))), array(self::attachment($signed_pdf, $document)));
    }

    public static function refusedToSender(array $document, array $organization)
    {
        Inbox::document($document, 'refused');
        $email = self::senderEmail($document);

        if ($email === '' || !UserPrefs::wants((int) $document['sender_id'], 'refused')) {
            return;
        }

        $title = sprintf(__('Refusé : %s', 'smbb-signconnect-proxima'), $document['filename']);
        $body = '<p>' . esc_html(sprintf(__('%1$s a refusé de signer « %2$s ».', 'smbb-signconnect-proxima'), $document['signer_name'] ?: $document['recipient_email'], $document['filename'])) . '</p>';

        if (!empty($document['refusal_message'])) {
            $body .= '<blockquote style="margin:16px 0;padding:12px 16px;background:#fff5f5;border-left:3px solid #cc1818;border-radius:4px;">' . nl2br(esc_html($document['refusal_message'])) . '</blockquote>';
        }

        self::email($organization, $email, $title, __('Signature refusée', 'smbb-signconnect-proxima'), $body, array(__('Voir mes envois', 'smbb-signconnect-proxima'), Token::appUrl(array('scp_view' => 'documents'))));
    }

    public static function expiredToSender(array $document, array $organization)
    {
        Inbox::document($document, 'expired');
        $email = self::senderEmail($document);

        if ($email === '' || !UserPrefs::wants((int) $document['sender_id'], 'expired')) {
            return;
        }

        $title = sprintf(__('Expiré sans signature : %s', 'smbb-signconnect-proxima'), $document['filename']);
        $body = '<p>' . esc_html(sprintf(__('Le lien envoyé à %1$s pour « %2$s » a expiré sans signature.', 'smbb-signconnect-proxima'), $document['recipient_email'] ?: $document['recipient_phone'], $document['filename'])) . '</p>';

        self::email($organization, $email, $title, __('Lien expiré', 'smbb-signconnect-proxima'), $body, array(__('Voir mes envois', 'smbb-signconnect-proxima'), Token::appUrl(array('scp_view' => 'documents'))));
    }

    /**
     * Gabarit HTML commun.
     *
     * @param array{0:string,1:string}|null $button libellé, URL
     * @param string[] $attachments
     */
    private static function email(array $organization, $to, $subject, $heading, $body_html, $button = null, array $attachments = array())
    {
        $color = Organizations::brandColor($organization);
        $logo = !empty($organization['logo_attachment_id']) ? wp_get_attachment_image_url((int) $organization['logo_attachment_id'], 'medium') : '';
        $html = '<!doctype html><html><body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;color:#111827;">';
        $html .= '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:32px 12px;"><tr><td align="center">';
        $html .= '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06);">';
        $html .= '<tr><td style="height:4px;background:' . esc_attr($color) . ';"></td></tr>';
        $html .= '<tr><td style="padding:28px 32px 8px;">';
        $html .= $logo ? '<img src="' . esc_url($logo) . '" alt="' . esc_attr($organization['name']) . '" style="max-height:40px;max-width:180px;display:block;margin-bottom:20px;">' : '<div style="font-size:13px;font-weight:600;color:#6b7280;margin-bottom:16px;">' . esc_html($organization['name']) . '</div>';
        $html .= '<h1 style="margin:0;font-size:22px;line-height:1.3;font-weight:600;">' . esc_html($heading) . '</h1></td></tr>';
        $html .= '<tr><td style="padding:8px 32px 24px;font-size:15px;line-height:1.6;">' . $body_html;

        if ($button) {
            $html .= '<p style="margin:28px 0 8px;"><a href="' . esc_url($button[1]) . '" style="display:inline-block;background:' . esc_attr($color) . ';color:#ffffff;text-decoration:none;font-weight:600;padding:12px 22px;border-radius:10px;">' . esc_html($button[0]) . '</a></p>';
            $html .= '<p style="font-size:12px;color:#9ca3af;word-break:break-all;">' . esc_html($button[1]) . '</p>';
        }

        $html .= '</td></tr><tr><td style="padding:16px 32px 24px;border-top:1px solid #f0f0f0;font-size:12px;color:#9ca3af;">' . esc_html(sprintf(__('Envoyé avec SignConnect pour %s.', 'smbb-signconnect-proxima'), $organization['name'])) . '</td></tr>';
        $html .= '</table></td></tr></table></body></html>';

        $sent = wp_mail($to, $subject, $html, array('Content-Type: text/html; charset=UTF-8'), array_filter($attachments));

        foreach ($attachments as $path) {
            if ($path && strpos(basename(dirname($path)), 'scp-mail-') === 0) {
                @unlink($path);
                @rmdir(dirname($path));
            }
        }

        if (!$sent) {
            throw new \RuntimeException(sprintf(__("L'email à %s n'a pas pu partir (vérifiez la configuration d'envoi des emails).", 'smbb-signconnect-proxima'), $to));
        }
    }

    /**
     * Copie temporaire nommée proprement (le nom du fichier joint est celui vu par le destinataire).
     */
    private static function attachment($path, array $document)
    {
        if (!$path || !is_readable($path)) {
            return '';
        }

        $name = sanitize_file_name(preg_replace('/\.pdf$/i', '', (string) $document['filename']) . '-signe.pdf');
        $dir = trailingslashit(get_temp_dir()) . 'scp-mail-' . wp_generate_password(8, false, false);
        wp_mkdir_p($dir);
        $target = $dir . '/' . $name;

        return copy($path, $target) ? $target : '';
    }

    private static function senderName(array $document)
    {
        $user = !empty($document['sender_id']) ? get_userdata((int) $document['sender_id']) : false;

        return $user ? (string) $user->display_name : __("L'expéditeur", 'smbb-signconnect-proxima');
    }

    private static function senderEmail(array $document)
    {
        $user = !empty($document['sender_id']) ? get_userdata((int) $document['sender_id']) : false;

        return $user && is_email($user->user_email) ? (string) $user->user_email : '';
    }

    private static function shorten($text, $length)
    {
        $text = (string) $text;

        return mb_strlen($text) > $length ? mb_substr($text, 0, $length - 1) . '…' : $text;
    }
}
