<?php

namespace Smbb\SignConnectProxima\Repository;

defined('ABSPATH') || exit;

/**
 * Lecture complète d'une organisation (réglages, clés, stockage).
 */
final class Organizations
{
    private static $rows = array();

    public static function find($id)
    {
        global $wpdb;

        $id = (int) $id;

        if ($id < 1) {
            return null;
        }

        if (!array_key_exists($id, self::$rows)) {
            $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . Lookup::table('scp_organization') . ' WHERE id = %d AND deleted_flag = 0', $id), ARRAY_A);

            if ($row) {
                $row = self::decryptSecrets($row);

                foreach (array('allowed_levels', 'internal_channels') as $key) {
                    $decoded = json_decode((string) $row[$key], true);
                    $row[$key] = is_array($decoded) ? array_values($decoded) : array();
                }
            }

            self::$rows[$id] = $row ?: null;
        }

        return self::$rows[$id];
    }

    /**
     * Clés API chiffrées en base par CodeTool (colonnes "secret") : déchiffrées pour les services.
     * Une valeur illisible (clé de chiffrement perdue) devient vide : le service la verra non configurée.
     */
    public static function decryptSecrets(array $row)
    {
        if (!class_exists('Smbb\\WpCodeTool\\Support\\Secrets')) {
            return $row;
        }

        foreach (array('universign_api_key', 'openai_api_key', 'twilio_token', 's3_secret_key') as $key) {
            if (isset($row[$key]) && \Smbb\WpCodeTool\Support\Secrets::isEncrypted($row[$key])) {
                $plain = \Smbb\WpCodeTool\Support\Secrets::decrypt($row[$key]);
                $row[$key] = $plain === null ? '' : $plain;
            }
        }

        return $row;
    }

    public static function canSend(array $organization)
    {
        return isset($organization['status']) && $organization['status'] === 'active';
    }

    public static function isBlocked(array $organization)
    {
        return isset($organization['status']) && $organization['status'] === 'blocked';
    }

    public static function hasS3(array $organization)
    {
        return !empty($organization['s3_bucket']) && !empty($organization['s3_access_key']) && !empty($organization['s3_secret_key']);
    }

    public static function hasUniversign(array $organization)
    {
        return !empty($organization['universign_api_key']);
    }

    /**
     * Niveaux cochés sur l'organisation et réellement utilisables (clé Universign pour les niveaux Universign).
     *
     * @return string[]
     */
    public static function availableLevels(array $organization)
    {
        $levels = array();

        foreach (\Smbb\SignConnectProxima\Support\Levels::all() as $level) {
            if (!in_array($level, (array) $organization['allowed_levels'], true)) {
                continue;
            }

            if ($level !== \Smbb\SignConnectProxima\Support\Levels::INTERNAL && !self::hasUniversign($organization)) {
                continue;
            }

            $levels[] = $level;
        }

        return $levels;
    }

    public static function hasTwilio(array $organization)
    {
        return !empty($organization['twilio_sid']) && !empty($organization['twilio_token']) && !empty($organization['twilio_from']);
    }

    /**
     * @return int[]
     */
    public static function reminderDays(array $organization)
    {
        $days = array_filter(array_map('intval', explode(',', (string) $organization['reminder_days'])));
        sort($days);

        return array_values(array_unique($days));
    }

    const DEFAULT_COLOR = '#db1f26';

    public static function brandColor(array $organization)
    {
        $color = isset($organization['brand_color']) ? (string) $organization['brand_color'] : '';

        // L'ancien bleu par défaut (#1e40af) suit le nouveau rouge SignConnect.
        if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $color) || strtolower($color) === '#1e40af') {
            return self::DEFAULT_COLOR;
        }

        return $color;
    }
}
