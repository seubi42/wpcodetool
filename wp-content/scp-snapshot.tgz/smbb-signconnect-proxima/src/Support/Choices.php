<?php

namespace Smbb\SignConnectProxima\Support;

defined('ABSPATH') || exit;

/**
 * Listes de valeurs fermées (statuts, rôles…) et leurs libellés.
 */
final class Choices
{
    public static function organizationStatuses()
    {
        return array(
            'active' => __('Active', 'smbb-signconnect-proxima'),
            'suspended' => __('Suspendue (plus de nouvel envoi)', 'smbb-signconnect-proxima'),
            'blocked' => __('Bloquée (envois et documents en cours bloqués)', 'smbb-signconnect-proxima'),
        );
    }

    public static function teamStatuses()
    {
        return array(
            'active' => __('Active', 'smbb-signconnect-proxima'),
            'archived' => __('Archivée', 'smbb-signconnect-proxima'),
        );
    }

    public static function planStatuses()
    {
        return array(
            'active' => __('Actif', 'smbb-signconnect-proxima'),
            'archived' => __('Archivé', 'smbb-signconnect-proxima'),
        );
    }

    public static function roles()
    {
        return array(
            'user' => __('Utilisateur', 'smbb-signconnect-proxima'),
            'team_supervisor' => __("Superviseur d'équipe", 'smbb-signconnect-proxima'),
            'org_supervisor' => __("Superviseur d'organisation", 'smbb-signconnect-proxima'),
            'org_admin' => __("Admin d'organisation", 'smbb-signconnect-proxima'),
        );
    }

    public static function universignModes()
    {
        return array(
            'smbb_workspace' => __('Espace de travail du compte SMBB', 'smbb-signconnect-proxima'),
            'own_account' => __('Compte Universign propre au client', 'smbb-signconnect-proxima'),
        );
    }

    public static function universignEnvironments()
    {
        return array(
            'preprod' => __('Préproduction (api.alpha.universign.com)', 'smbb-signconnect-proxima'),
            'prod' => __('Production (api.universign.com)', 'smbb-signconnect-proxima'),
        );
    }

    public static function authMeans()
    {
        return array(
            'sms' => __('Code par SMS', 'smbb-signconnect-proxima'),
            'email' => __('Code par email', 'smbb-signconnect-proxima'),
        );
    }

    public static function channels()
    {
        return array(
            'email' => __('Email', 'smbb-signconnect-proxima'),
            'sms' => __('SMS (Twilio)', 'smbb-signconnect-proxima'),
        );
    }

    public static function documentStatuses()
    {
        return array(
            'draft' => __('Brouillon', 'smbb-signconnect-proxima'),
            'sent' => __('Envoyé', 'smbb-signconnect-proxima'),
            'opened' => __('Ouvert', 'smbb-signconnect-proxima'),
            'signed' => __('Signé', 'smbb-signconnect-proxima'),
            'refused' => __('Refusé', 'smbb-signconnect-proxima'),
            'expired' => __('Expiré', 'smbb-signconnect-proxima'),
            'cancelled' => __('Annulé', 'smbb-signconnect-proxima'),
            'purged' => __('Purgé', 'smbb-signconnect-proxima'),
        );
    }

    public static function detectionSources()
    {
        return array(
            'template' => __('Modèle reconnu', 'smbb-signconnect-proxima'),
            'ai' => __('Détection IA', 'smbb-signconnect-proxima'),
            'manual' => __('Placement manuel', 'smbb-signconnect-proxima'),
        );
    }

    public static function storageLocations()
    {
        return array(
            'none' => __('Aucun', 'smbb-signconnect-proxima'),
            's3' => __('S3 de l\'organisation', 'smbb-signconnect-proxima'),
            'universign' => __('Universign', 'smbb-signconnect-proxima'),
        );
    }

    /**
     * Libellé d'une valeur dans une des listes ci-dessus.
     */
    public static function label($list, $value)
    {
        $values = method_exists(__CLASS__, $list) ? call_user_func(array(__CLASS__, $list)) : array();

        return isset($values[$value]) ? $values[$value] : (string) $value;
    }

    /**
     * Inverse une liste valeur => libellé vers le format attendu par Form::setOptions().
     */
    public static function options($list)
    {
        $values = method_exists(__CLASS__, $list) ? call_user_func(array(__CLASS__, $list)) : array();

        return array_flip($values);
    }

    /**
     * Pastille de statut HTML (déjà échappée).
     */
    public static function badge($list, $value)
    {
        return '<span class="scp-badge scp-badge--' . esc_attr(sanitize_html_class((string) $value)) . '">'
            . esc_html(self::label($list, $value))
            . '</span>';
    }
}
