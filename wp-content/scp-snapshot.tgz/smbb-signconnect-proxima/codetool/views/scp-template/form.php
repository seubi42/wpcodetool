<?php
/**
 * Modèle de détection, propre à une organisation.
 *
 * @var \Smbb\WpCodeTool\Admin\Form $form
 */

use Smbb\SignConnectProxima\Admin\TemplateEditor;
use Smbb\SignConnectProxima\Admin\View;
use Smbb\SignConnectProxima\Repository\Lookup;
use Smbb\SignConnectProxima\Support\Levels;

defined('ABSPATH') || exit;

$d = 'smbb-signconnect-proxima';
$item = isset($item) && is_array($item) ? $item : array();
$is_new = empty($item['id']);

$fields = array(
    $form->section(__('Modèle', $d), __('Sert à reconnaître un document à l\'envoi et à placer ses champs automatiquement.', $d), array(
        $form->row(
            $form->select(__('Organisation', $d))->setName('organization_id')->setOptions(Lookup::organizationOptions(__('— Choisir —', $d)))->required(),
            $form->text(__('Nom', $d))->setName('name')->required(),
            $form->toggle(__('Actif', $d))->setName('is_active')
        ),
        $form->textarea(__('Description', $d), array('rows' => 2))->setName('description'),
        $form->media(__("PDF d'exemple", $d), array('library' => 'application/pdf'))->setName('sample_pdf_attachment_id'),
    ))->setIcon('dashicons-layout'),
    $form->section(__('Niveau de signature', $d), '', array(
        $form->row(
            $form->select(__('Niveau proposé', $d))->setName('suggested_level')->setOptions(Levels::options()),
            $form->toggle(__('Niveau imposé', $d))->setName('level_enforced')
                ->setHelp(__("L'utilisateur ne peut pas choisir un niveau plus faible.", $d))
        ),
    ))->setIcon('dashicons-yes-alt'),
    $form->section(__('Zones', $d), __("Placez les champs à signer et les zones qui permettent de reconnaître ce document. Pensez à enregistrer.", $d), array(
        TemplateEditor::html($item),
        $form->textarea(__('Zones de reconnaissance (JSON)', $d), array('rows' => 3))->setName('detection_zones')
            ->setHelp(__("Rempli par l'éditeur. Format : [{\"page\":1,\"x\":0.1,\"y\":0.05,\"width\":0.4,\"height\":0.05,\"text\":\"CONTRAT DE VENTE\"}]", $d)),
        $form->textarea(__('Champs à placer (JSON)', $d), array('rows' => 3))->setName('field_zones')
            ->setHelp(__("Rempli par l'éditeur. Page -1 = dernière page du document.", $d)),
    ))->setIcon('dashicons-editor-table'),
);

$html = '<div class="form_container">' . $form->save($is_new ? __('Créer le modèle', $d) : __('Enregistrer', $d))->setFields($fields) . '</div>';

View::page($html, isset($page_header_html) ? $page_header_html : '', isset($notices_html) ? $notices_html : '', __('Modèle de détection', $d));
