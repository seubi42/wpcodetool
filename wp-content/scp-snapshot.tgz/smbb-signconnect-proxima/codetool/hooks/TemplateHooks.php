<?php

namespace Smbb\SignConnectProxima\CodeTool;

use Smbb\SignConnectProxima\Repository\AuditLog;
use Smbb\SignConnectProxima\Repository\Lookup;
use Smbb\SignConnectProxima\Support\Input;
use Smbb\SignConnectProxima\Support\Levels;

defined('ABSPATH') || exit;

final class TemplateHooks
{
    public function beforeValidate(array $data, array $context = array())
    {
        $data = Input::stripManaged($data);
        $data = Input::trim($data, array('name'));
        $data = Input::nullableIds($data, array('sample_pdf_attachment_id'));
        unset($data['match_count']);

        // Les zones arrivent en JSON texte, rempli par l'éditeur visuel (ou à la main).
        foreach (array('detection_zones', 'field_zones') as $key) {
            if (isset($data[$key]) && is_string($data[$key])) {
                $data[$key] = trim($data[$key]) === '' ? '[]' : trim($data[$key]);
            }
        }

        return $data;
    }

    public function validate(array $data, array $context = array())
    {
        $errors = array();

        if (empty($data['organization_id']) || !array_key_exists((int) $data['organization_id'], Lookup::organizations())) {
            $errors['organization_id'] = __('Choisissez une organisation.', 'smbb-signconnect-proxima');
        }

        if (empty($data['name'])) {
            $errors['name'] = __('Le nom du modèle est obligatoire.', 'smbb-signconnect-proxima');
        }

        if (isset($data['suggested_level']) && !in_array($data['suggested_level'], Levels::all(), true)) {
            $errors['suggested_level'] = __('Niveau inconnu.', 'smbb-signconnect-proxima');
        }

        foreach (array('detection_zones', 'field_zones') as $key) {
            if (isset($data[$key]) && is_string($data[$key])) {
                $decoded = json_decode($data[$key], true);

                if (!is_array($decoded)) {
                    $errors[$key] = __('JSON invalide : une liste de zones est attendue.', 'smbb-signconnect-proxima');
                }
            }
        }

        return $errors;
    }

    public function afterSave(array $row, array $context = array())
    {
        $is_create = isset($context['action']) && $context['action'] === 'create';

        AuditLog::record(
            $is_create ? 'template_created' : 'template_updated',
            sprintf(
                $is_create ? __('Modèle « %s » créé.', 'smbb-signconnect-proxima') : __('Modèle « %s » modifié.', 'smbb-signconnect-proxima'),
                isset($row['name']) ? $row['name'] : ''
            ),
            array('template_id' => isset($row['id']) ? (int) $row['id'] : 0),
            isset($row['organization_id']) ? (int) $row['organization_id'] : null
        );
    }

    public function beforeDelete(array $row, array $context = array())
    {
        AuditLog::record('template_deleted', sprintf(__('Modèle « %s » supprimé.', 'smbb-signconnect-proxima'), isset($row['name']) ? $row['name'] : ''), array(), isset($row['organization_id']) ? (int) $row['organization_id'] : null);

        return true;
    }
}
